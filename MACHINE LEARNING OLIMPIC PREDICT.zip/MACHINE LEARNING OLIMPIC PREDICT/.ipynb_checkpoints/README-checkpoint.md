# Project Overview

This Project includes creating a hypothesis, setting up the model, and measuring error. This is a machine learning project using Python and Jupyter.

We'll try to predict how many medals a country will win based on historical and current data.


# Machine learning project steps

Most machine learning projects follow a similar outline, which we'll also follow here.  This outline will help you tackle any machine learning problem.

**Project Steps**

1. Form a hypothesis.
    we can predict  how many medals a county
2. Find and explore the data.
    - previous medals and medals(the predictions)
3. (If necessary) Reshape the data to predict your target.
    -no need to reshape the data a lot because we need to create the medals(predictions) how many medals that they will win 
    
4. Clean the data for ML.
    -we making sure that theres no missing data, because most Machine Learing cannot work with missing values
    for some teams we cannot found some previous values couse they was not compeete the previuous olympic 
    
5. Pick an error metric.
    use to evaluate the performent of the ML models
    we will create predictions row that diffrent with the actual medals count
    we need to figured out that those the prediction are good or not.
    the way that we do that is use an ERROR METRIC ( WE USE mean absolut error)
    createing error columb that (medals-prevmedals) and we create mean of the individuals error. sum error adn devide by the total number 
    of the predictions we made that gives us what called the mean absolute error.
    thats the metric we're going to use to evaluate if our algorithm is making predictions effectively.

6. Split your data. this is will tell us how well the algoritm is performing
   we will plit it into 2 data, the train data and the test(hasn't trained) data to evaluate the algoritm
   so we will train the algoritm in the train data and test it on the test data.
   we will measure the mean absolute error so how well the algoritms makes predictions properly or not
   
7. Train a model.
    we will use the linear regression which is very popular machine learing model
    and it works with an equation y=ax+B that equation we will use to train our model
    how that can work?
    we'll make y-absis for the predic medals and 
    x-axis medals in the last 
    example : if the country may have gotten one medals in the last olympic and 3 medals in th current olympic and you'll see point at the
    (1,3)
    the linear regression will draw a line between the point and we can use that line to make predictions.
    what this line does is, it lets us predict new data using past data so we've trained the slope of this line using the equation at the
    equations (y= ax + B), the ecuation dictates the y interceot and the slope of the line. and we can use this line to predict data that we havent trained it on so for example if a country got six medals in the last olympic we can look the line and we can see that, it corespond to about six medals in this olympic, so would predict that, that country would get six medals in  the current olympics.
    so if a country have 6 medals in 2016, we will predict that they will get 6 medals in 2020
    the model that we gonna train is going to slighly more complicated than this model this is what's called univariate or single variable linear regression, where we we're inly using previous medals so the medasl  a country got in the last olympics to predict the medals they'll get in this olympic but we're gonna do somthing that a little bit complicated in our actual model and we're actually going to use 2 predictors
    we'll use this equations (Y= ax1 + ax2 + B)
    2 predictors
    1. nuymber of athletes a country is entered in to th e olympic and 
    2. how many medals thay got in the prev olympics
    so we're going ti train a model that takes into account both of those factors and then we're gonna make predictions.
    
    
## Code

You can find the code for this project [here](https://github.com/dataquestio/project-walkthroughs/tree/master/beginner_ml).

File overview:

* `machine_learning.ipynb` - the main project code
* `data_prep.ipynb` - the code to generate the team-level dataset from an athlete-level dataset

# Local Setup

## Installation

To follow this project, please install the following locally:

* Python 3.8+
* Python packages
    * pandas
    * numpy
    * scikit-learn
    * seaborn


## Data

We'll be using data from the Olympics, which was originally on [Kaggle](https://www.kaggle.com/datasets/heesoo37/120-years-of-olympic-history-athletes-and-results).

You can download the files we'll use in this project here:

* [teams.csv](https://drive.google.com/uc?export=download&id=1L3YAlts8tijccIndVPB-mOsRpEpVawk7) - the team-level data that we use in this project.
* [athlete_events.csv](https://drive.google.com/uc?export=download&id=1Ah4wOyNFMGREq8Yw_Jbv7u2CeI_6tpn5) - this is the original athlete-level data